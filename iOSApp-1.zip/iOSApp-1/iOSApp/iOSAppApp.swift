//
//  iOSAppApp.swift
//  iOSApp
//
//  Created by Aditya Majumdar on 12/12/23.

import SwiftUI
import Firebase
import GoogleSignIn

@main
struct iOSAppApp: App {
    // Initialize Firebase
    init() {
        FirebaseApp.configure()
    }
    
    @AppStorage("isLoggedIn") var isLoggedIn = false
    @State private var navigateToFirstPage = false
    // Create an instance of your user data model
    let userData = UserData()
    
    var body: some Scene {
        WindowGroup {
            NavigationView {
                if isLoggedIn {
                    FirstPage()
                        .navigationBarBackButtonHidden(true)
                } else {
                    ContentView()
                        .environmentObject(userData)
                }
            }
            .onAppear {
                // Check if the user is already logged in upon app launch
                if isLoggedIn {
                    navigateToFirstPage = true
                }
            }
        }
    }
}
