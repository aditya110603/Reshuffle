import SwiftUI
import Firebase
import FirebaseAuth
import FirebaseFirestore
import CoreLocation

struct CardListView: View {
    
    @State private var searchCards: String = ""
    @State private var contacts: [Contact] = []

    var body: some View {
        NavigationView {
            VStack {
                Text("Saved Cards")
                    .font(.largeTitle)
                    .fontWeight(.bold)
                    .padding()

                TextField("🔍    Search names, companies, and professions", text: $searchCards)
                    .padding()
                    .textFieldStyle(RoundedBorderTextFieldStyle())
                    .background(RoundedRectangle(cornerRadius: 10).fill(Color.white))

                List {
                    ForEach(filteredContacts) { contact in
                        CardListItemView(contact: contact)
                    }
                    .onDelete { indices in
                        // Extract the UID of the deleted contact
                        let deletedContactUIDs = indices.map { contacts[$0].uid }
                        
                        // Update the scannedUIDs in Firestore
                        guard let currentUserUID = Auth.auth().currentUser?.uid else {
                            return
                        }
                        
                        let savedUsersRef = Firestore.firestore().collection("SavedUsers").document(currentUserUID)
                        
                        savedUsersRef.getDocument { (document, error) in
                            if let document = document, document.exists {
                                var scannedUIDs = document.data()?["scannedUIDs"] as? [String] ?? []
                                
                                // Remove the UIDs of deleted contacts from scannedUIDs
                                for deletedUID in deletedContactUIDs {
                                    if let indexToRemove = scannedUIDs.firstIndex(of: deletedUID) {
                                        scannedUIDs.remove(at: indexToRemove)
                                    }
                                }
                                
                                // Update Firestore with the modified scannedUIDs
                                savedUsersRef.setData(["scannedUIDs": scannedUIDs], merge: true) { error in
                                    if let error = error {
                                        print("Error updating scannedUIDs: \(error.localizedDescription)")
                                    } else {
                                        print("scannedUIDs updated successfully")
                                    }
                                }
                                
                                // Remove the contacts from the list
                                self.contacts.remove(atOffsets: indices)
                            } else {
                                print("Error fetching SavedUsers document: \(error?.localizedDescription ?? "")")
                            }
                        }
                    }
                }
                .listStyle(PlainListStyle())
            }
        }
        .onAppear {
            fetchData()
        }
        .navigationBarTitle("", displayMode: .inline)
    }

    var filteredContacts: [Contact] {
        if searchCards.isEmpty {
            return contacts
        } else {
            return contacts.filter { $0.matches(search: searchCards) }
        }
    }
    
    func fetchData() {
            guard let currentUserUID = Auth.auth().currentUser?.uid else {
                return
            }

            let savedUsersRef = Firestore.firestore().collection("SavedUsers").document(currentUserUID)

            savedUsersRef.getDocument { (document, error) in
                if let document = document, document.exists {
                    if let scannedUIDs = document.data()?["scannedUIDs"] as? [String] {
                        // Fetch user details for each scanned UID
                        for scannedUID in scannedUIDs {
                            fetchUserDetails(for: scannedUID)
                        }
                    }
                } else {
                    print("Error fetching SavedUsers document: \(error?.localizedDescription ?? "")")
                }
            }
        }

        func fetchUserDetails(for uid: String) {
            let userDatabaseRef = Firestore.firestore().collection("UserDatabase").document(uid)

            userDatabaseRef.getDocument { (document, error) in
                if let document = document, document.exists {
                    if let data = document.data() {
                        // Extract user details and create a Contact object
                        let contact = Contact(
                            uid: uid,
                            firstName: data["name"] as? String ?? "",
                            lastName: "",
                            designation: data["profession"] as? String ?? "",
                            company: data["company"] as? String ?? "",
                            coordinate: CLLocationCoordinate2D(),
                            email: data["email"] as? String ?? "",
                            role: data["role"] as? String ?? "",
                            description: data["description"] as? String ?? "",
                            phoneNumber: data["phoneNumber"] as? String ?? "",
                            whatsapp: data["whatsapp"] as? String ?? "",
                            address: data["address"] as? String ?? "",
                            website: data["website"] as? String ?? "",
                            linkedIn: data["linkedIn"] as? String ?? "",
                            instagram: data["instagram"] as? String ?? "",
                            xHandle: data["xHandle"] as? String ?? ""
                        )

                        // Add the contact to the list
                        self.contacts.append(contact)
                    }
                } else {
                    print("Error fetching UserDatabase document for UID \(uid): \(error?.localizedDescription ?? "")")
                }
            }
        }
    }

struct CardListItemView: View {
    let contact: Contact
    @State private var showDetails = false // State to control the visibility of details popup
    @Environment(\.presentationMode) var presentationMode


    var body: some View {
        Button(action: {
            self.showDetails.toggle()
        }) {
            HStack {
                Image(systemName: "person.circle.fill")
                    .resizable()
                    .frame(width: 40, height: 40)
                    .foregroundColor(.blue)
                    .padding(.trailing, 8)

                VStack(alignment: .leading) {
                    Text("\(contact.firstName)")
                        .font(.headline)
                    Text("\(contact.designation), \(contact.company)")
                        .font(.subheadline)
                        .foregroundColor(.gray)
                }
            }
            .padding(8)
        }
        .sheet(isPresented: $showDetails) {
            DetailsPopupView(contact: contact)
        }
    }
}

struct DetailsPopupView: View {
    let contact: Contact
    @State private var userData: UserDataBusinessCard?
    @State private var isFetchingData = false
    
    var body: some View {
        VStack(alignment: .leading) {
            if let userData = userData {
                // Display BusinessCardSaved with user details
                BusinessCardSaved(userData: Binding.constant(userData))
                    .padding()
                    .frame(width: 320, height: 380) // Adjust the size as needed
            } else {
                // Show loading indicator or error message if data is still being fetched or an error occurred
                if isFetchingData {
                    ProgressView("Fetching user data...")
                } else {
                    Text("Error fetching user data.")
                }
            }
        }
        .onAppear {
            fetchUserDetails()
        }
    }

        func fetchUserDetails() {
            isFetchingData = true

            // Fetch user details from "UserDatabase" using the contact's email as a reference
            Firestore.firestore().collection("UserDatabase")
                .whereField("email", isEqualTo: contact.email)
                .getDocuments { querySnapshot, error in
                    DispatchQueue.main.async {
                        defer {
                            isFetchingData = false
                        }

                        if let error = error {
                            print("Error fetching user details: \(error.localizedDescription)")
                            return
                        }

                        guard let documents = querySnapshot?.documents, let document = documents.first else {
                            print("User details not found")
                            return
                        }

                        do {
                            let user = try document.data(as: UserDataBusinessCard.self)
                            userData = user
                        } catch {
                            print("Error decoding user data: \(error.localizedDescription)")
                        }
                    }
                }
        }
    }

struct Contact: Identifiable, Equatable, Hashable {
    let id = UUID()
    let uid: String // Add this property
    let firstName: String
    let lastName: String
    let designation: String
    let company: String
    let coordinate: CLLocationCoordinate2D
    
    // Additional details
    let email: String
    let role: String
    let description: String
    let phoneNumber: String
    let whatsapp: String
    let address: String
    let website: String
    let linkedIn: String
    let instagram: String
    let xHandle: String

    func matches(search: String) -> Bool {
        let searchString = search.lowercased()
        return firstName.lowercased().contains(searchString)
            || designation.lowercased().contains(searchString)
            || company.lowercased().contains(searchString)
    }
    
    static func == (lhs: Contact, rhs: Contact) -> Bool {
        return lhs.id == rhs.id
    }

    func hash(into hasher: inout Hasher) {
        hasher.combine(id)
    }
}

struct CardListView_Previews: PreviewProvider {
    static var previews: some View {
        let cardListView = CardListView()
        CardListView()
    }
}
