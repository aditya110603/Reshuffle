import SwiftUI
import CoreImage
import UIKit

struct QRCodeView: View {
    let qrCodeData: String

    // Function to generate a QR code from the input data
    private func generateQRCode() -> Image? {
        guard let data = qrCodeData.data(using: .utf8) else { return nil }

        let context = CIContext()
        guard let filter = CIFilter(name: "CIQRCodeGenerator") else { return nil }
        filter.setValue(data, forKey: "inputMessage")

        // Adjust the scale to improve the resolution
        let scale = UIScreen.main.scale
        let transform = CGAffineTransform(scaleX: scale, y: scale)
        guard let outputImage = filter.outputImage?.transformed(by: transform) else { return nil }

        if let cgImage = context.createCGImage(outputImage, from: outputImage.extent) {
            let uiImage = UIImage(cgImage: cgImage)
            return Image(uiImage: uiImage)
        } else {
            return nil
        }
    }

    var body: some View {
        Group {
            if let qrCodeImage = generateQRCode() {
                qrCodeImage
                    .resizable()
                    .aspectRatio(contentMode: .fill)
                    .frame(width: 125, height: 125) 
            } else {
                // Placeholder or error handling if QR code cannot be generated
                Text("Unable to generate QR code")
            }
        }
    }
}

struct QRCodeView_Previews: PreviewProvider {
    static var previews: some View {
        QRCodeView(qrCodeData: "Sample QR Code Data") // Provide a sample QR code data for preview
    }
}
