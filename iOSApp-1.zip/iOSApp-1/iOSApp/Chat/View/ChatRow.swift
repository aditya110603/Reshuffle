//
//  ChatRow.swift
//  iOSApp
//
//  Created by Aditya Majumdar on 25/02/24.
//

import SwiftUI

struct ChatRow : View {
    
    var message : MessageChat
    var uid : String
    @Environment(\.imageCache) var cache: ImageCache
    
    var body: some View {
        
        HStack {
            if message.imageUrl != nil{
                if message.fromId == uid {
                    HStack {
                        Spacer()
                        image
                    }.padding(.leading,75)
                } else {
                    HStack {
                        image
                        Spacer()
                    }.padding(.trailing,75)
                }
            } else {
                if message.fromId == uid {
                    HStack {
                        Spacer()
                        Text(message.text ?? "")
                            .modifier(chatModifier(myMessage: true))
                    }.padding(.leading,75)
                } else {
                    HStack {
                        Text(message.text ?? "")
                            .modifier(chatModifier(myMessage: false))
                        Spacer()
                    }.padding(.trailing,75)
                }
            }
        }
    }
    
    private var image: some View {
        AsyncImage(
            url: URL(string: message.imageUrl ?? "")!,
            cache: cache,
            placeholder: ShimmerView().frame(width: 291, height: 291),
            configuration: { $0.resizable().renderingMode(.original) }
        )
            .aspectRatio(contentMode: .fit)
            .frame(idealWidth: 291, idealHeight: 291)
            .cornerRadius(10)
    }
}


struct chatModifier : ViewModifier{
    var myMessage : Bool
    func body(content: Content) -> some View {
        content
            .padding(10)
            .background(myMessage ? Color.blue : Color("bg1"))
            .cornerRadius(7)
            .foregroundColor(Color.white)
    }
}


struct ChatViewRow : View {
    var user : UserDataChat
    var message : MessageChat
    var session: SessionStore
    
    @Environment(\.imageCache) var cache: ImageCache
    @State private var isChatLogViewPresented = false
    
    var body : some View {
        NavigationLink(destination: ChatLogView(user: user, session: session)) {
            HStack{
                profilePicture.padding(.trailing,10)
                VStack(alignment: .leading, spacing: 3){
                    HStack{
                        Text(user.name ?? "")
                            .font(.system(size: 15, weight: .semibold))
                        Spacer()
                        Text("\(message.timestamp?.timeStringConverter ?? "")")
                            .font(.system(size: 12, weight: .regular))
                            .foregroundColor(.blue)
                    }
                    Text(message.text ?? "")
                        .font(.system(size: 12, weight: .medium))
                        .foregroundColor(.secondary)
                }
            }
        }
        .simultaneousGesture(TapGesture().onEnded {
            // Handle tap gesture to navigate to ChatLogView
            self.isChatLogViewPresented.toggle()
        })
        .background(
            NavigationLink("", destination: ChatLogView(user: user, session: session), isActive: $isChatLogViewPresented)
                .opacity(0)
        )
    }
    
    private var profilePicture: some View {
        if let imageUrl = user.profileImageUrl, let url = URL(string: imageUrl) {
            return AnyView(
                AsyncImage(
                    url: url,
                    cache: cache,
                    placeholder: Image(systemName: "person.fill"),
                    configuration: { $0.resizable().renderingMode(.original) }
                )
                .aspectRatio(contentMode: .fit)
                .frame(idealHeight: 56 )
                .clipShape(Circle())
            )
        } else {
            return AnyView(
                Image(systemName: "person.fill")
                    .resizable()
                    .aspectRatio(contentMode: .fit)
                    .frame(idealHeight: 55)
                    .clipShape(Circle())
            )
        }
    }


}

