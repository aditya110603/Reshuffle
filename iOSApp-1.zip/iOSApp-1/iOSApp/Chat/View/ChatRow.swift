//
//  ChatRow.swift
//  iOSApp
//
//  Created by Aditya Majumdar on 25/02/24.
//

import SwiftUI

struct ChatRow : View {
    
    var message : MessageChat
    var uid : String
    @Environment(\.imageCache) var cache: ImageCache
    
    var body: some View {
        
        HStack {
            if message.imageUrl != nil{
                if message.fromId == uid {
                    HStack {
                        Spacer()
                        image
                    }.padding(.leading,75)
                } else {
                    HStack {
                        image
                        Spacer()
                    }.padding(.trailing,75)
                }
            } else {
                if message.fromId == uid {
                    HStack {
                        Spacer()
                        Text(message.text ?? "")
                            .modifier(chatModifier(myMessage: true))
                    }.padding(.leading,75)
                } else {
                    HStack {
                        Text(message.text ?? "")
                            .modifier(chatModifier(myMessage: false))
                        Spacer()
                    }.padding(.trailing,75)
                }
            }
        }
    }
    
    private var image: some View {
        AsyncImage(
            url: URL(string: message.imageUrl ?? "")!,
            cache: cache,
            placeholder: ShimmerView().frame(width: 291, height: 291),
            configuration: { $0.resizable().renderingMode(.original) }
        )
            .aspectRatio(contentMode: .fit)
            .frame(idealWidth: 291, idealHeight: 291)
            .cornerRadius(10)
    }
}


struct chatModifier : ViewModifier{
    var myMessage : Bool
    func body(content: Content) -> some View {
        content
            .padding(10)
            .background(myMessage ? Color.blue : Color("bg1"))
            .cornerRadius(7)
            .foregroundColor(Color.white)
    }
}


struct ChatViewRow: View {
    var user: UserDataChat
    var message: MessageChat
    var session: SessionStore
    
    @Environment(\.imageCache) var cache: ImageCache
    @State private var isChatLogViewPresented = false
    @State private var profilePictureURL: String? = nil
    @State private var isLoadingProfilePicture = false // Track loading state
    
    var body: some View {
        NavigationLink(destination: ChatLogView(user: user, session: session)) {
            HStack {
                profilePictureView
                    .padding(.trailing, 10)
                
                VStack(alignment: .leading, spacing: 3) {
                    HStack {
                        Text(user.name ?? "")
                            .font(.system(size: 15, weight: .semibold))
                        Spacer()
                        Text("\(message.timestamp?.timeStringConverter ?? "")")
                            .font(.system(size: 12, weight: .regular))
                            .foregroundColor(.black)
                    }
                    Text(message.text ?? "")
                        .font(.system(size: 12, weight: .medium))
                        .foregroundColor(.secondary)
                }
            }
        }
        .onAppear {
            // Fetch the profile picture URL if not already loading
            if !isLoadingProfilePicture {
                isLoadingProfilePicture = true
                fetchProfilePicture()
            }
        }
        .simultaneousGesture(TapGesture().onEnded {
            // Handle tap gesture to navigate to ChatLogView
            self.isChatLogViewPresented.toggle()
        })
        .background(
            NavigationLink("", destination: ChatLogView(user: user, session: session), isActive: $isChatLogViewPresented)
                .opacity(0)
        )
    }
    
    private func fetchProfilePicture() {
        guard let url = URL(string: user.profilePictureURL ?? "") else {
            isLoadingProfilePicture = false
            return
        }
        
        URLSession.shared.dataTask(with: url) { data, response, error in
            defer {
                isLoadingProfilePicture = false
            }
            
            if let data = data {
                // Successfully fetched data
                DispatchQueue.main.async {
                    profilePictureURL = url.absoluteString
                }
            } else {
                // Handle error
                print("Failed to fetch profile picture:", error?.localizedDescription ?? "Unknown error")
            }
        }.resume()
    }
    
    @ViewBuilder
    private var profilePictureView: some View {
        let imageSize: CGFloat = 50
        
        if let urlString = profilePictureURL, let url = URL(string: urlString) {
            AsyncImage(
                url: url,
                cache: cache,
                placeholder:
                    Image(systemName: "person.circle.fill")
                        .resizable()
                        .aspectRatio(contentMode: .fill)
                        .frame(width: imageSize, height: imageSize)
                        .clipShape(Circle())
                ,
                configuration: { $0.resizable().renderingMode(.original) }
            )
            .aspectRatio(contentMode: .fill)
            .frame(width: imageSize, height: imageSize)
            .clipShape(Circle())
        } else {
            Image(systemName: "person.circle.fill")
                .resizable()
                .aspectRatio(contentMode: .fill)
                .frame(width: imageSize, height: imageSize)
                .clipShape(Circle())
        }
    }
}


