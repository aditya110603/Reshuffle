//
//  ChatsView.swift
//  iOSApp
//
//  Created by Aditya Majumdar on 25/02/24.
//


import SwiftUI

struct ChatsView: View {
    @State var messagesDictionary = [String: MessageChat]()
    @ObservedObject var session: SessionStore
    @State var showNewChatsView: Bool = false
    @State var user = UserDataChat()
    @State var activateNavigation: Bool = false

    var body: some View {
            NavigationView {
                List(session.messages, id: \.id) { message in
                    ZStack {
                        NavigationLink(destination: ChatLogView(user: self.session.getUserFromMSG(message), session: self.session)) {
                            EmptyView()
                        }.hidden()
                        ChatViewRow(user: self.session.getUserFromMSG(message), message: message, session: self.session)
                    }
                }
                .navigationBarTitle(Text("Chats"), displayMode: .large)
                .navigationBarItems(
                    leading: HStack {
                        newChatButton
                        Text("New Chat")
                    }
                )
                .sheet(isPresented: $showNewChatsView) {
                    NewChatsView(session: self.session)
                }
                .onAppear {
                    // Fetch all users from 'users' collection
                    self.session.fetchUsers(isSavedUsers: false)
                }
            }
        }

        var newChatButton: Button<Image> {
            return Button(action: newChat) {
                Image(systemName: "plus")
            }
        }

        func newChat() {
            showNewChatsView = true
        }
    }


//import SwiftUI
//
//struct ChatsView: View {
//    @State var messagesDictionary = [String: MessageChat]()
//    @ObservedObject var session: SessionStore
//    @State var showNewChatsView: Bool = false
//    @State var user = UserDataChat()
//    @State var activateNavigation: Bool = false
//
//    var body: some View {
//        NavigationView {
//            List(session.messages, id: \.id) { message in
//                ZStack {
//                    NavigationLink(destination: ChatLogView(user: self.session.getUserFromMSG(message), session: self.session)) {
//                        EmptyView()
//                    }.hidden()
//                    ChatViewRow(user: self.session.getUserFromMSG(message), message: message, session: self.session)
//                }
//            }
//            .navigationBarTitle(Text("Chats"), displayMode: .large)
//            .navigationBarItems(
//                leading: HStack {
//                    newChatButton
//                    Text("New Chat")
//                }
//            )
//            .sheet(isPresented: $showNewChatsView) {
//                NewChatsView(session: self.session)
//            }
//        }
//    }
//
//    var newChatButton: Button<Image> {
//        return Button(action: newChat) {
//            Image(systemName: "plus")
//        }
//    }
//
//    func newChat() {
//        showNewChatsView = true
//    }
//
//    func getUser(_ message: MessageChat) {
//        session.getUserFromMessage(message) { (user) in
//            self.user = user
//            self.activateNavigation = true
//        }
//    }
//}
