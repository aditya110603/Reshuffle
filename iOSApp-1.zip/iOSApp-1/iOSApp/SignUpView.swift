import SwiftUI
import FirebaseAuth
import Firebase
import FirebaseAuth
import FirebaseFirestore
import AuthenticationServices
import GoogleSignIn



struct SignupView: View {
    @State private var fullName = ""
    @State private var email = ""
    @State private var password = ""
    @State private var confirmPassword = ""
    @State private var isOnboardingActive = false
    @ObservedObject var userData: UserData
    @State private var isErrorAlertPresented = false
    @State private var errorMessage = ""

    var body: some View {
        NavigationView {
            VStack {
                Spacer()

                Text("Create account")
                    .font(.title)
                    .fontWeight(.bold)
                    .padding()

                Text("Sign up to get started!")
                    .foregroundColor(.gray)
                    .padding()

                VStack(spacing: 16) {
                    TextField("Full Name", text: $fullName)
                        .padding()
                        .textFieldStyle(RoundedBorderTextFieldStyle())

                    TextField("Email address", text: $email)
                        .padding()
                        .textFieldStyle(RoundedBorderTextFieldStyle())
                        .autocapitalization(.none)
                        .keyboardType(.emailAddress)

                    SecureField("Password", text: $password)
                        .padding()
                        .textFieldStyle(RoundedBorderTextFieldStyle())

                    SecureField("Confirm password", text: $confirmPassword)
                        .padding()
                        .textFieldStyle(RoundedBorderTextFieldStyle())
                }
                .padding(.horizontal)

                NavigationLink(destination: Onboarding(userData: userData).navigationBarBackButtonHidden(true), isActive: $isOnboardingActive) {
                    Button(action: {
                        signUpWithFirebase()
                    }) {
                        Text("Sign up")
                            .foregroundColor(.white)
                            .padding()
                            .frame(maxWidth: .infinity)
                            .background(Color.blue)
                            .cornerRadius(20)
                    }
                    .padding(.horizontal)
                }

//                Text("OR")
//                    .font(.caption)
//                    .foregroundColor(.black)
//                    .padding(.top, 8)
//
//                Text("Continue with")
//                    .foregroundColor(.black)
//
//                HStack {
//                    Button(action: {
//                        print("Sign Up using Apple")
//                    }) {
//                        Image(systemName: "applelogo")
//                            .resizable()
//                            .frame(width: 40, height: 40)
//                            .foregroundColor(.black)
//                            .padding()
//                            .background(Color.white)
//                            .cornerRadius(200)
//                    }
//                    .padding(.horizontal)
//
//                    Button(action: {
//                        print("Sign Up using Google")
//                    }) {
//                        Image("googlelogo")
//                            .resizable()
//                            .frame(width: 40, height: 40)
//                            .foregroundColor(.black)
//                            .padding()
//                            .background(Color.white)
//                            .cornerRadius(200)
//                    }
//                    .padding(.horizontal)
//                }

                HStack {
                    Text("Already a member?")

                    NavigationLink(destination: LoginView(userData: userData).navigationBarBackButtonHidden(true)) {
                        Text("Sign In")
                            .foregroundColor(.blue)
                            .fontWeight(.bold)
                    }
                }
                .padding()

                if !errorMessage.isEmpty {
                    Text(errorMessage)
                        .foregroundColor(.red)
                        .padding(.top, 8)
                }
                
                Spacer()
                
                Image("Reshufflelogo")
                                    .resizable()
                                    .aspectRatio(contentMode: .fit)
                                    .frame(width: 200, height: 80)
                                    .padding()

                Spacer()
            }
            .alert(isPresented: $isErrorAlertPresented) {
                Alert(title: Text("Error"), message: Text(errorMessage), dismissButton: .default(Text("OK")))
            }
        }
    }

    private func signUpWithFirebase() {
        if !isValidEmail(email) {
            errorMessage = "Invalid email format."
            isErrorAlertPresented = true
            return
        }

        if !isValidPassword(password) {
            errorMessage = "Invalid password format. Password must be at least 6 characters."
            isErrorAlertPresented = true
            return
        }

        Auth.auth().createUser(withEmail: email, password: password) { authResult, error in
                    if let error = error {
                        print("Error signing up: \(error.localizedDescription)")
                        errorMessage = "Invalid email or password. Please try again."
                        isErrorAlertPresented = true
                    } else {
                        // Successfully signed up
                        print("Successfully signed up!")

                        // Check if the user is not nil before navigating
                        if let user = authResult?.user {
                            // Populate userData dictionary with user information
                            var userData: [String: Any] = [
                                "uid": user.uid,
                                                    "email": user.email ?? "",
                                                    "profilePictureURL": "", // Set the profile picture URL as needed
                                                    "username": fullName  // Set the username as needed
                            ]

                            // Store user data in Firestore
                            Firestore.firestore().collection("users").document(user.uid).setData(userData) { error in
                                if let error = error {
                                    print("Error storing user data: \(error.localizedDescription)")
                                    errorMessage = "Failed to store user data."
                                    isErrorAlertPresented = true
                                } else {
                                    print("Successfully signed up and stored user data!")
                                    Firestore.firestore().collection("user-messages").document(user.uid).setData([:]) { error in
                                                if let error = error {
                                                    print("Error creating user-messages document: \(error.localizedDescription)")
                                                    // Handle error as needed
                                                }
                                        else {
                                                        print("Successfully created user-messages document!")
                                                        isOnboardingActive = true
                                                    }
                                                }
                                    let scannedUIDsData: [String: Any] = [
                                                            "scannedUIDs": []  // Initialize with an empty array
                                                        ]
                                    Firestore.firestore().collection("SavedUsers").document(user.uid).setData(scannedUIDsData) { error in
                                                if let error = error {
                                                    print("Error creating SacedUsers document: \(error.localizedDescription)")
                                                    // Handle error as needed
                                                }
                                        else {
                                                        print("Successfully created SavedUsers document!")
                                                        isOnboardingActive = true
                                                    }
                                                }
                                    
                                    let locationsData: [String: Any] = [
                                            "PublicLocation": "ON" // Set PublicLocation to ON by default
                                        ]
                                    
                                    Firestore.firestore().collection("Location").document(user.uid).setData(locationsData) { error in
                                                if let error = error {
                                                    print("Error creating SacedUsers document: \(error.localizedDescription)")
                                                    // Handle error as needed
                                                }
                                        else {
                                                        print("Successfully created Locations document!")
                                                        isOnboardingActive = true
                                                    }
                                                }
                                }
                            }
                        } else {
                            errorMessage = "User is nil after sign-up."
                            isErrorAlertPresented = true
                        }
                    }
                }
            }

    private func isValidEmail(_ email: String) -> Bool {
        let emailRegex = "[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,}"
        let emailPredicate = NSPredicate(format: "SELF MATCHES %@", emailRegex)
        return emailPredicate.evaluate(with: email)
    }

    private func isValidPassword(_ password: String) -> Bool {
        return password.count >= 6
    }
}

struct SignupView_Previews: PreviewProvider {
    static var previews: some View {
        let userData = UserData() // Create UserData instance
        SignupView(userData: userData) // Pass UserData instance to SignupView
    }
}

